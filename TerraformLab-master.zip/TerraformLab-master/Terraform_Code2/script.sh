echo "testing" >> /tmp/testing
