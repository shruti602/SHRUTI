echo "testing" > /var/tmp/testfile
